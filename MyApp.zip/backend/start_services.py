import subprocess
import sys
import time
import os

def start_services():
    print("Starting Hospital Management System Backend Services...")
    
    # Install requirements if needed
    try:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'], check=True)
        print("Dependencies installed successfully.")
    except subprocess.CalledProcessError:
        print("Failed to install dependencies.")
        return
    
    # Start Patient Service
    print("Starting Patient Service on port 5001...")
    patient_service = subprocess.Popen([
        sys.executable, 'patient_service/app.py'
    ], cwd=os.getcwd())
    
    time.sleep(2)
    
    # Start Appointment Service
    print("Starting Appointment Service on port 5002...")
    appointment_service = subprocess.Popen([
        sys.executable, 'appointment_service/app.py'
    ], cwd=os.getcwd())
    
    print("Both services are running!")
    print("Patient Service: http://localhost:5001")
    print("Appointment Service: http://localhost:5002")
    print("Press Ctrl+C to stop all services")
    
    try:
        # Keep the script running
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping services...")
        patient_service.terminate()
        appointment_service.terminate()
        print("Services stopped.")

if __name__ == '__main__':
    start_services()