from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import json
import requests
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Initialize SQLite database
def init_db():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    
    # Create doctors table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            department TEXT NOT NULL,
            experience INTEGER NOT NULL,
            available_slots TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create appointments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id INTEGER NOT NULL,
            patient_name TEXT NOT NULL,
            patient_mobile TEXT NOT NULL,
            doctor_id INTEGER NOT NULL,
            doctor_name TEXT NOT NULL,
            department TEXT NOT NULL,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            status TEXT DEFAULT 'scheduled',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (doctor_id) REFERENCES doctors (id)
        )
    ''')
    
    conn.commit()
    conn.close()

# Doctor endpoints
@app.route('/api/doctors', methods=['GET'])
def get_doctors():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM doctors ORDER BY created_at DESC')
    doctors = cursor.fetchall()
    conn.close()
    
    doctor_list = []
    for doctor in doctors:
        doctor_list.append({
            'id': doctor[0],
            'name': doctor[1],
            'department': doctor[2],
            'experience': doctor[3],
            'available_slots': json.loads(doctor[4]),
            'created_at': doctor[5]
        })
    
    return jsonify(doctor_list)

@app.route('/api/doctors', methods=['POST'])
def create_doctor():
    data = request.get_json()
    
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO doctors (name, department, experience, available_slots)
        VALUES (?, ?, ?, ?)
    ''', (data['name'], data['department'], data['experience'], json.dumps(data['available_slots'])))
    
    doctor_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    return jsonify({'id': doctor_id, 'message': 'Doctor created successfully'}), 201

@app.route('/api/doctors/<int:doctor_id>', methods=['GET'])
def get_doctor(doctor_id):
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM doctors WHERE id = ?', (doctor_id,))
    doctor = cursor.fetchone()
    conn.close()
    
    if doctor:
        return jsonify({
            'id': doctor[0],
            'name': doctor[1],
            'department': doctor[2],
            'experience': doctor[3],
            'available_slots': json.loads(doctor[4]),
            'created_at': doctor[5]
        })
    else:
        return jsonify({'error': 'Doctor not found'}), 404

# Appointment endpoints
@app.route('/api/appointments', methods=['GET'])
def get_appointments():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM appointments ORDER BY created_at DESC')
    appointments = cursor.fetchall()
    conn.close()
    
    appointment_list = []
    for appointment in appointments:
        appointment_list.append({
            'id': appointment[0],
            'patient_id': appointment[1],
            'patient_name': appointment[2],
            'patient_mobile': appointment[3],
            'doctor_id': appointment[4],
            'doctor_name': appointment[5],
            'department': appointment[6],
            'appointment_date': appointment[7],
            'appointment_time': appointment[8],
            'status': appointment[9],
            'created_at': appointment[10]
        })
    
    return jsonify(appointment_list)

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    data = request.get_json()
    
    # Validate patient exists
    try:
        patient_response = requests.get(f'http://localhost:5001/api/patients/{data["patient_id"]}')
        if patient_response.status_code != 200:
            return jsonify({'error': 'Patient not found'}), 404
        patient_data = patient_response.json()
    except:
        return jsonify({'error': 'Unable to validate patient'}), 500
    
    # Check doctor availability
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    
    # Get doctor details
    cursor.execute('SELECT * FROM doctors WHERE id = ?', (data['doctor_id'],))
    doctor = cursor.fetchone()
    if not doctor:
        conn.close()
        return jsonify({'error': 'Doctor not found'}), 404
    
    # Check if time slot is available
    cursor.execute('''
        SELECT COUNT(*) FROM appointments 
        WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ?
    ''', (data['doctor_id'], data['appointment_date'], data['appointment_time']))
    
    if cursor.fetchone()[0] > 0:
        conn.close()
        return jsonify({'error': 'Time slot not available'}), 400
    
    # Create appointment
    cursor.execute('''
        INSERT INTO appointments (patient_id, patient_name, patient_mobile, doctor_id, doctor_name, department, appointment_date, appointment_time)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (data['patient_id'], patient_data['name'], patient_data['mobile'], 
          data['doctor_id'], doctor[1], doctor[2], data['appointment_date'], data['appointment_time']))
    
    appointment_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Simulate SMS notification
    sms_message = f"Appointment confirmed! Dr. {doctor[1]} ({doctor[2]}) on {data['appointment_date']} at {data['appointment_time']}. MediCare Hospital."
    
    return jsonify({
        'id': appointment_id, 
        'message': 'Appointment booked successfully',
        'sms_sent': sms_message
    }), 201

@app.route('/api/appointments/<int:appointment_id>/complete', methods=['PUT'])
def complete_appointment(appointment_id):
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE appointments 
        SET status = 'completed'
        WHERE id = ?
    ''', (appointment_id,))
    
    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Appointment not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Appointment marked as completed'})

@app.route('/api/appointments/doctor/<int:doctor_id>', methods=['GET'])
def get_doctor_appointments(doctor_id):
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM appointments WHERE doctor_id = ? ORDER BY appointment_date, appointment_time', (doctor_id,))
    appointments = cursor.fetchall()
    conn.close()
    
    appointment_list = []
    for appointment in appointments:
        appointment_list.append({
            'id': appointment[0],
            'patient_id': appointment[1],
            'patient_name': appointment[2],
            'patient_mobile': appointment[3],
            'doctor_id': appointment[4],
            'doctor_name': appointment[5],
            'department': appointment[6],
            'appointment_date': appointment[7],
            'appointment_time': appointment[8],
            'status': appointment[9],
            'created_at': appointment[10]
        })
    
    return jsonify(appointment_list)

@app.route('/api/appointments/patient/<int:patient_id>', methods=['GET'])
def get_patient_appointments(patient_id):
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM appointments WHERE patient_id = ? ORDER BY appointment_date DESC, appointment_time DESC', (patient_id,))
    appointments = cursor.fetchall()
    conn.close()
    
    appointment_list = []
    for appointment in appointments:
        appointment_list.append({
            'id': appointment[0],
            'patient_id': appointment[1],
            'patient_name': appointment[2],
            'patient_mobile': appointment[3],
            'doctor_id': appointment[4],
            'doctor_name': appointment[5],
            'department': appointment[6],
            'appointment_date': appointment[7],
            'appointment_time': appointment[8],
            'status': appointment[9],
            'created_at': appointment[10]
        })
    
    return jsonify(appointment_list)

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5002)