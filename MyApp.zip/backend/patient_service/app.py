from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Initialize SQLite database
def init_db():
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            mobile TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

# Get all patients
@app.route('/api/patients', methods=['GET'])
def get_patients():
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM patients ORDER BY created_at DESC')
    patients = cursor.fetchall()
    conn.close()
    
    patient_list = []
    for patient in patients:
        patient_list.append({
            'id': patient[0],
            'name': patient[1],
            'age': patient[2],
            'gender': patient[3],
            'mobile': patient[4],
            'created_at': patient[5]
        })
    
    return jsonify(patient_list)

# Create new patient
@app.route('/api/patients', methods=['POST'])
def create_patient():
    data = request.get_json()
    
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO patients (name, age, gender, mobile)
        VALUES (?, ?, ?, ?)
    ''', (data['name'], data['age'], data['gender'], data['mobile']))
    
    patient_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    return jsonify({'id': patient_id, 'message': 'Patient created successfully'}), 201

# Get patient by ID
@app.route('/api/patients/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM patients WHERE id = ?', (patient_id,))
    patient = cursor.fetchone()
    conn.close()
    
    if patient:
        return jsonify({
            'id': patient[0],
            'name': patient[1],
            'age': patient[2],
            'gender': patient[3],
            'mobile': patient[4],
            'created_at': patient[5]
        })
    else:
        return jsonify({'error': 'Patient not found'}), 404

# Update patient
@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    data = request.get_json()
    
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE patients 
        SET name = ?, age = ?, gender = ?, mobile = ?
        WHERE id = ?
    ''', (data['name'], data['age'], data['gender'], data['mobile'], patient_id))
    
    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Patient not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Patient updated successfully'})

# Delete patient
@app.route('/api/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    conn = sqlite3.connect('patients.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM patients WHERE id = ?', (patient_id,))
    
    if cursor.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Patient not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Patient deleted successfully'})

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5001)