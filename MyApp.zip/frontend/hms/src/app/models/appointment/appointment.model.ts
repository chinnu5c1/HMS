export interface Appointment {
  id?: number;
  patient_id: number;
  doctor_id: number;
  appointment_date: string;
  time_slot: string;
  status: string;
  patient_name?: string;
  doctor_name?: string;
  doctor_department?: string;
  created_at?: string;
}