export interface Doctor {
  id?: number;
  name: string;
  department: string;
  experience: number;
  available_slots: string[];
  created_at?: string;
}