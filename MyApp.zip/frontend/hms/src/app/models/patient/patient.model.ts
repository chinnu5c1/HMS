export interface Patient {
  id?: number;
  name: string;
  age: number;
  gender: string;
  mobile: string;
  created_at?: string;
}