import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from '../../services/doctor.service';
import { PatientService } from '../../services/patient.service';
import { AppointmentService } from '../../services/appointment.service';
import { Doctor } from '../../models/doctor/doctor.model';
import { Patient } from '../../models/patient/patient.model';

@Component({
  selector: 'app-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container my-5">
      <h2 class="section-title">Book Appointment</h2>
      
      <!-- Patient Selection -->
      <div class="card mb-4 fade-in" *ngIf="!selectedPatientId">
        <div class="card-header">
          <h4><i class="fas fa-user me-2"></i>Select Patient</h4>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Choose Patient *</label>
              <select class="form-control" [(ngModel)]="selectedPatientId" name="patientId">
                <option value="">Select a patient</option>
                <option *ngFor="let patient of patients" [value]="patient.id">
                  {{patient.name}} - {{patient.mobile}}
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Selected Patient Info -->
      <div class="alert alert-info fade-in" *ngIf="selectedPatient">
        <i class="fas fa-info-circle me-2"></i>
        Booking appointment for: <strong>{{selectedPatient.name}}</strong> ({{selectedPatient.mobile}})
      </div>

      <!-- Doctors List -->
      <div class="card fade-in" *ngIf="selectedPatientId">
        <div class="card-header">
          <h4><i class="fas fa-user-md me-2"></i>Available Doctors ({{doctors.length}})</h4>
        </div>
        <div class="card-body">
          <div class="row" *ngIf="doctors.length > 0; else noDoctors">
            <div class="col-lg-6 col-xl-4 mb-4" *ngFor="let doctor of doctors">
              <div class="card doctor-card h-100">
                <div class="card-body">
                  <div class="d-flex align-items-start mb-3">
                    <div class="doctor-avatar me-3">
                      {{doctor.name.charAt(0).toUpperCase()}}
                    </div>
                    <div class="flex-grow-1">
                      <h5 class="card-title mb-1">Dr. {{doctor.name}}</h5>
                      <span class="badge badge-department">{{doctor.department}}</span>
                    </div>
                  </div>
                  
                  <div class="doctor-details mb-3">
                    <p class="mb-2">
                      <i class="fas fa-graduation-cap me-2 text-primary"></i>
                      {{doctor.experience}} years experience
                    </p>
                    <p class="mb-2">
                      <i class="fas fa-stethoscope me-2 text-success"></i>
                      Specialized in {{doctor.department}}
                    </p>
                  </div>

                  <div class="mb-3">
                    <h6 class="mb-2">Available Time Slots:</h6>
                    <div class="available-slots">
                      <div class="time-slot" 
                           *ngFor="let slot of doctor.available_slots"
                           [class.selected]="selectedSlot === slot && selectedDoctorId === doctor.id"
                           (click)="selectTimeSlot(doctor.id!, slot)">
                        {{slot}}
                      </div>
                    </div>
                  </div>

                  <div class="d-grid">
                    <button class="btn btn-primary" 
                            [disabled]="selectedDoctorId !== doctor.id || !selectedSlot || isBooking"
                            (click)="bookAppointment(doctor)">
                      <span *ngIf="isBooking && selectedDoctorId === doctor.id" class="loading-spinner me-2"></span>
                      <i class="fas fa-calendar-plus me-2"></i>
                      Book Appointment
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <ng-template #noDoctors>
            <div class="text-center py-5">
              <i class="fas fa-user-md-slash fa-3x text-muted mb-3"></i>
              <h5 class="text-muted">No doctors available</h5>
              <p class="text-muted">Please check back later or contact administration</p>
            </div>
          </ng-template>
        </div>
      </div>

      <!-- Success Message Modal -->
      <div class="modal fade" [class.show]="showSuccessModal" [style.display]="showSuccessModal ? 'block' : 'none'" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header bg-success text-white">
              <h5 class="modal-title">
                <i class="fas fa-check-circle me-2"></i>Appointment Confirmed!
              </h5>
            </div>
            <div class="modal-body">
              <div class="text-center mb-4">
                <i class="fas fa-calendar-check fa-3x text-success mb-3"></i>
                <h4>Appointment Booked Successfully!</h4>
              </div>
              
              <div class="appointment-details">
                <div class="row">
                  <div class="col-6"><strong>Patient:</strong></div>
                  <div class="col-6">{{bookedAppointment?.patient_name}}</div>
                </div>
                <div class="row">
                  <div class="col-6"><strong>Doctor:</strong></div>
                  <div class="col-6">Dr. {{bookedAppointment?.doctor_name}}</div>
                </div>
                <div class="row">
                  <div class="col-6"><strong>Department:</strong></div>
                  <div class="col-6">{{bookedAppointment?.doctor_department}}</div>
                </div>
                <div class="row">
                  <div class="col-6"><strong>Date:</strong></div>
                  <div class="col-6">{{bookedAppointment?.appointment_date}}</div>
                </div>
                <div class="row">
                  <div class="col-6"><strong>Time:</strong></div>
                  <div class="col-6">{{bookedAppointment?.time_slot}}</div>
                </div>
              </div>

              <div class="alert alert-info mt-3">
                <i class="fas fa-sms me-2"></i>
                <strong>SMS Notification:</strong> Confirmation message sent to {{selectedPatient?.mobile}}
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success" (click)="closeSuccessModal()">
                <i class="fas fa-check me-2"></i>OK
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Modal Backdrop -->
      <div class="modal-backdrop fade" [class.show]="showSuccessModal" *ngIf="showSuccessModal"></div>
    </div>
  `
})
export class AppointmentComponent implements OnInit {
  doctors: Doctor[] = [];
  patients: Patient[] = [];
  selectedPatientId: number | null = null;
  selectedPatient: Patient | null = null;
  selectedDoctorId: number | null = null;
  selectedSlot: string = '';
  showSuccessModal = false;
  bookedAppointment: any = null;
  isBooking = false;

  constructor(
    private doctorService: DoctorService,
    private patientService: PatientService,
    private appointmentService: AppointmentService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadDoctors();
    this.loadPatients();
    
    // Check if patient ID is provided in query params
    this.route.queryParams.subscribe(params => {
      if (params['patientId']) {
        this.selectedPatientId = parseInt(params['patientId']);
        this.loadSelectedPatient();
      }
    });
  }

  loadDoctors() {
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
      },
      error: (error) => {
        console.error('Error loading doctors:', error);
      }
    });
  }

  loadPatients() {
    this.patientService.getPatients().subscribe({
      next: (data) => {
        this.patients = data;
      },
      error: (error) => {
        console.error('Error loading patients:', error);
      }
    });
  }

  loadSelectedPatient() {
    if (this.selectedPatientId) {
      this.patientService.getPatient(this.selectedPatientId).subscribe({
        next: (patient) => {
          this.selectedPatient = patient;
        },
        error: (error) => {
          console.error('Error loading patient:', error);
        }
      });
    }
  }

  selectTimeSlot(doctorId: number, slot: string) {
    this.selectedDoctorId = doctorId;
    this.selectedSlot = slot;
  }

  bookAppointment(doctor: Doctor) {
    if (!this.selectedPatientId || !this.selectedSlot) {
      return;
    }

    this.isBooking = true;
    
    const appointmentData = {
      patient_id: this.selectedPatientId,
      doctor_id: doctor.id,
      appointment_date: new Date().toISOString().split('T')[0], // Today's date
      time_slot: this.selectedSlot
    };

    this.appointmentService.createAppointment(appointmentData).subscribe({
      next: (appointment) => {
        this.bookedAppointment = {
          ...appointment,
          patient_name: this.selectedPatient?.name,
          doctor_name: doctor.name,
          doctor_department: doctor.department
        };
        this.showSuccessModal = true;
        this.isBooking = false;
        
        // Reset selections
        this.selectedDoctorId = null;
        this.selectedSlot = '';
      },
      error: (error) => {
        console.error('Error booking appointment:', error);
        this.isBooking = false;
        alert('Error booking appointment. Please try again.');
      }
    });
  }

  closeSuccessModal() {
    this.showSuccessModal = false;
    this.bookedAppointment = null;
    this.router.navigate(['/patients']);
  }
}