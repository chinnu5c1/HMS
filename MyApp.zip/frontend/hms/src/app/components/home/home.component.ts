import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="hero-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <h1 class="hero-title">
              <i class="fas fa-hospital-alt me-3"></i>
              MediCare Hospital
            </h1>
            <p class="hero-subtitle">
              Advanced Healthcare Management System - Providing Quality Care with Modern Technology
            </p>
            <div class="mt-4">
              <a routerLink="/patients" class="btn btn-light btn-lg me-3">
                <i class="fas fa-user-plus me-2"></i>Patient Services
              </a>
              <a routerLink="/doctors" class="btn btn-outline-light btn-lg">
                <i class="fas fa-user-md me-2"></i>Doctor Portal
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container my-5">
      <h2 class="section-title">Our Services</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card h-100 fade-in">
            <div class="card-body text-center p-4">
              <div class="mb-3">
                <i class="fas fa-user-plus fa-3x text-primary"></i>
              </div>
              <h4 class="card-title">Patient Registration</h4>
              <p class="card-text">Quick and easy patient registration with comprehensive medical record management.</p>
              <a routerLink="/patients" class="btn btn-primary">Get Started</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card h-100 fade-in">
            <div class="card-body text-center p-4">
              <div class="mb-3">
                <i class="fas fa-calendar-check fa-3x text-success"></i>
              </div>
              <h4 class="card-title">Appointment Booking</h4>
              <p class="card-text">Schedule appointments with our expert doctors at your convenient time.</p>
              <a routerLink="/appointments" class="btn btn-success">Book Now</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card h-100 fade-in">
            <div class="card-body text-center p-4">
              <div class="mb-3">
                <i class="fas fa-user-md fa-3x text-info"></i>
              </div>
              <h4 class="card-title">Doctor Portal</h4>
              <p class="card-text">Comprehensive dashboard for doctors to manage appointments and patient care.</p>
              <a routerLink="/doctor-dashboard" class="btn btn-info">Access Portal</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-light py-5">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <h3 class="mb-4">Why Choose MediCare?</h3>
            <ul class="list-unstyled">
              <li class="mb-3">
                <i class="fas fa-check-circle text-success me-3"></i>
                24/7 Emergency Services
              </li>
              <li class="mb-3">
                <i class="fas fa-check-circle text-success me-3"></i>
                Expert Medical Team
              </li>
              <li class="mb-3">
                <i class="fas fa-check-circle text-success me-3"></i>
                Modern Healthcare Technology
              </li>
              <li class="mb-3">
                <i class="fas fa-check-circle text-success me-3"></i>
                Patient-Centered Care
              </li>
            </ul>
          </div>
          <div class="col-lg-6 text-center">
            <i class="fas fa-heartbeat fa-5x text-danger mb-4"></i>
            <h4>Your Health, Our Priority</h4>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent {}