import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PatientService } from '../../services/patient.service';
import { AppointmentService } from '../../services/appointment.service';
import { Patient } from '../../models/patient/patient.model';
import { Appointment } from '../../models/appointment/appointment.model';

@Component({
  selector: 'app-patient',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="container my-5">
      <h2 class="section-title">Patient Management</h2>
      
      <!-- Patient Registration Form -->
      <div class="card mb-5 fade-in">
        <div class="card-header">
          <h4><i class="fas fa-user-plus me-2"></i>Patient Registration</h4>
        </div>
        <div class="card-body">
          <form (ngSubmit)="savePatient()" #patientForm="ngForm">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Full Name *</label>
                <input type="text" class="form-control" [(ngModel)]="newPatient.name" name="name" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Age *</label>
                <input type="number" class="form-control" [(ngModel)]="newPatient.age" name="age" required min="1">
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Gender *</label>
                <select class="form-control" [(ngModel)]="newPatient.gender" name="gender" required>
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Mobile Number *</label>
                <input type="tel" class="form-control" [(ngModel)]="newPatient.mobile" name="mobile" required pattern="[0-9]{10}">
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary btn-lg" [disabled]="!patientForm.form.valid || isLoading">
                <span *ngIf="isLoading" class="loading-spinner me-2"></span>
                <i class="fas fa-save me-2"></i>Save Patient
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Success Message -->
      <div class="alert alert-success fade-in" *ngIf="showSuccessMessage">
        <i class="fas fa-check-circle me-2"></i>
        Patient registered successfully!
      </div>

      <!-- Patients List -->
      <div class="card fade-in">
        <div class="card-header">
          <h4><i class="fas fa-users me-2"></i>Registered Patients ({{patients.length}})</h4>
        </div>
        <div class="card-body">
          <div class="row" *ngIf="patients.length > 0; else noPatients">
            <div class="col-lg-6 col-xl-4 mb-4" *ngFor="let patient of patients">
              <div class="card doctor-card h-100">
                <div class="card-body">
                  <div class="d-flex align-items-start mb-3">
                    <div class="doctor-avatar me-3">
                      {{patient.name.charAt(0).toUpperCase()}}
                    </div>
                    <div class="flex-grow-1">
                      <h5 class="card-title mb-1">{{patient.name}}</h5>
                      <p class="text-muted mb-0">Patient ID: #{{patient.id}}</p>
                    </div>
                  </div>
                  
                  <div class="patient-details mb-3">
                    <p class="mb-1"><i class="fas fa-birthday-cake me-2 text-primary"></i>Age: {{patient.age}} years</p>
                    <p class="mb-1"><i class="fas fa-venus-mars me-2 text-primary"></i>Gender: {{patient.gender}}</p>
                    <p class="mb-1"><i class="fas fa-phone me-2 text-primary"></i>{{patient.mobile}}</p>
                  </div>
                  
                  <div class="d-grid gap-2">
                    <a routerLink="/appointments" [queryParams]="{patientId: patient.id}" class="btn btn-success">
                      <i class="fas fa-calendar-plus me-2"></i>Book Appointment
                    </a>
                    <button (click)="viewPreviousAppointments(patient.id!)" class="btn btn-info">
                      <i class="fas fa-history me-2"></i>Previous Appointments
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <ng-template #noPatients>
            <div class="text-center py-5">
              <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
              <h5 class="text-muted">No patients registered yet</h5>
              <p class="text-muted">Start by registering your first patient above</p>
            </div>
          </ng-template>
        </div>
      </div>

      <!-- Previous Appointments Modal -->
      <div class="modal fade" [class.show]="showAppointmentsModal" [style.display]="showAppointmentsModal ? 'block' : 'none'" tabindex="-1">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="fas fa-history me-2"></i>Previous Appointments
              </h5>
              <button type="button" class="btn-close" (click)="closeAppointmentsModal()"></button>
            </div>
            <div class="modal-body">
              <div *ngIf="selectedPatientAppointments.length > 0; else noAppointments">
                <div class="card mb-3" *ngFor="let appointment of selectedPatientAppointments">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                      <div>
                        <h6 class="card-title">
                          <i class="fas fa-user-md me-2"></i>Dr. {{appointment.doctor_name}}
                        </h6>
                        <p class="mb-1">
                          <span class="badge badge-department">{{appointment.doctor_department}}</span>
                        </p>
                        <p class="mb-1">
                          <i class="fas fa-calendar me-2"></i>{{appointment.appointment_date}}
                        </p>
                        <p class="mb-0">
                          <i class="fas fa-clock me-2"></i>{{appointment.time_slot}}
                        </p>
                      </div>
                      <div>
                        <span class="badge" 
                              [class.bg-success]="appointment.status === 'completed'"
                              [class.bg-warning]="appointment.status === 'scheduled'"
                              [class.bg-info]="appointment.status === 'confirmed'">
                          {{appointment.status | titlecase}}
                        </span>
                      </div>
                    </div>
                    <div *ngIf="appointment.status === 'completed'" class="mt-2">
                      <div class="alert alert-success mb-0">
                        <i class="fas fa-check-circle me-2"></i>
                        Thanks for consulting with Dr. {{appointment.doctor_name}}!
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <ng-template #noAppointments>
                <div class="text-center py-4">
                  <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                  <h5 class="text-muted">No appointments found</h5>
                  <p class="text-muted">This patient hasn't booked any appointments yet</p>
                </div>
              </ng-template>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeAppointmentsModal()">Close</button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Modal Backdrop -->
      <div class="modal-backdrop fade" [class.show]="showAppointmentsModal" *ngIf="showAppointmentsModal"></div>
    </div>
  `
})
export class PatientComponent implements OnInit {
  patients: Patient[] = [];
  newPatient: Patient = {
    name: '',
    age: 0,
    gender: '',
    mobile: ''
  };
  
  selectedPatientAppointments: Appointment[] = [];
  showAppointmentsModal = false;
  showSuccessMessage = false;
  isLoading = false;

  constructor(
    private patientService: PatientService,
    private appointmentService: AppointmentService
  ) {}

  ngOnInit() {
    this.loadPatients();
  }

  loadPatients() {
    this.patientService.getPatients().subscribe({
      next: (data) => {
        this.patients = data;
      },
      error: (error) => {
        console.error('Error loading patients:', error);
      }
    });
  }

  savePatient() {
    this.isLoading = true;
    this.patientService.createPatient(this.newPatient).subscribe({
      next: (data) => {
        this.patients.push(data);
        this.newPatient = { name: '', age: 0, gender: '', mobile: '' };
        this.showSuccessMessage = true;
        this.isLoading = false;
        
        setTimeout(() => {
          this.showSuccessMessage = false;
        }, 3000);
      },
      error: (error) => {
        console.error('Error saving patient:', error);
        this.isLoading = false;
      }
    });
  }

  viewPreviousAppointments(patientId: number) {
    this.appointmentService.getPatientAppointments(patientId).subscribe({
      next: (appointments) => {
        this.selectedPatientAppointments = appointments;
        this.showAppointmentsModal = true;
      },
      error: (error) => {
        console.error('Error loading appointments:', error);
      }
    });
  }

  closeAppointmentsModal() {
    this.showAppointmentsModal = false;
    this.selectedPatientAppointments = [];
  }
}