import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AppointmentService } from '../../services/appointment.service';
import { Doctor } from '../../models/doctor/doctor.model';
import { Appointment } from '../../models/appointment/appointment.model';

@Component({
  selector: 'app-doctor-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container my-5">
      <div *ngIf="currentDoctor; else notLoggedIn">
        <!-- Doctor Info Header -->
        <div class="card mb-4 fade-in">
          <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center">
                <div class="doctor-avatar me-3">
                  {{currentDoctor.name.charAt(0).toUpperCase()}}
                </div>
                <div>
                  <h4 class="mb-0">Dr. {{currentDoctor.name}}</h4>
                  <p class="mb-0 opacity-75">{{currentDoctor.department}} Department</p>
                </div>
              </div>
              <button class="btn btn-light" (click)="logout()">
                <i class="fas fa-sign-out-alt me-2"></i>Logout
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="row text-center">
              <div class="col-md-4">
                <h5 class="text-primary">{{currentDoctor.experience}}</h5>
                <p class="text-muted mb-0">Years Experience</p>
              </div>
              <div class="col-md-4">
                <h5 class="text-success">{{appointments.length}}</h5>
                <p class="text-muted mb-0">Total Appointments</p>
              </div>
              <div class="col-md-4">
                <h5 class="text-info">{{getTodayAppointments().length}}</h5>
                <p class="text-muted mb-0">Today's Appointments</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Available Slots -->
        <div class="card mb-4 fade-in">
          <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-clock me-2"></i>Available Time Slots</h5>
          </div>
          <div class="card-body">
            <div class="available-slots">
              <span class="time-slot me-2 mb-2" *ngFor="let slot of currentDoctor.available_slots">
                {{slot}}
              </span>
            </div>
          </div>
        </div>

        <!-- Appointments List -->
        <div class="card fade-in">
          <div class="card-header">
            <h5 class="mb-0">
              <i class="fas fa-calendar-alt me-2"></i>
              My Appointments ({{appointments.length}})
            </h5>
          </div>
          <div class="card-body">
            <div *ngIf="appointments.length > 0; else noAppointments">
              <!-- Today's Appointments -->
              <div *ngIf="getTodayAppointments().length > 0" class="mb-4">
                <h6 class="text-primary mb-3">
                  <i class="fas fa-calendar-day me-2"></i>Today's Appointments
                </h6>
                <div class="row">
                  <div class="col-lg-6 mb-3" *ngFor="let appointment of getTodayAppointments()">
                    <div class="card border-primary">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                          <div>
                            <h6 class="card-title mb-1">
                              <i class="fas fa-user me-2"></i>{{appointment.patient_name}}
                            </h6>
                            <p class="text-muted mb-1">
                              <i class="fas fa-clock me-2"></i>{{appointment.time_slot}}
                            </p>
                            <p class="text-muted mb-0">
                              <i class="fas fa-calendar me-2"></i>{{appointment.appointment_date}}
                            </p>
                          </div>
                          <span class="badge" 
                                [class.bg-warning]="appointment.status === 'scheduled'"
                                [class.bg-info]="appointment.status === 'confirmed'"
                                [class.bg-success]="appointment.status === 'completed'">
                            {{appointment.status | titlecase}}
                          </span>
                        </div>
                        <div class="d-grid" *ngIf="appointment.status !== 'completed'">
                          <button class="btn btn-success btn-sm" 
                                  (click)="markConsultationDone(appointment)"
                                  [disabled]="isUpdating">
                            <span *ngIf="isUpdating" class="loading-spinner me-2"></span>
                            <i class="fas fa-check me-2"></i>Mark Consultation Done
                          </button>
                        </div>
                        <div *ngIf="appointment.status === 'completed'" class="alert alert-success mb-0 mt-2">
                          <i class="fas fa-check-circle me-2"></i>
                          Consultation completed successfully!
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- All Appointments -->
              <div>
                <h6 class="text-secondary mb-3">
                  <i class="fas fa-list me-2"></i>All Appointments
                </h6>
                <div class="row">
                  <div class="col-lg-6 mb-3" *ngFor="let appointment of appointments">
                    <div class="card">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                          <div>
                            <h6 class="card-title mb-1">
                              <i class="fas fa-user me-2"></i>{{appointment.patient_name}}
                            </h6>
                            <p class="text-muted mb-1">
                              <i class="fas fa-clock me-2"></i>{{appointment.time_slot}}
                            </p>
                            <p class="text-muted mb-0">
                              <i class="fas fa-calendar me-2"></i>{{appointment.appointment_date}}
                            </p>
                          </div>
                          <div class="text-end">
                            <span class="badge mb-2" 
                                  [class.bg-warning]="appointment.status === 'scheduled'"
                                  [class.bg-info]="appointment.status === 'confirmed'"
                                  [class.bg-success]="appointment.status === 'completed'">
                              {{appointment.status | titlecase}}
                            </span>
                            <br>
                            <small class="text-muted">
                              {{isToday(appointment.appointment_date) ? 'Today' : formatDate(appointment.appointment_date)}}
                            </small>
                          </div>
                        </div>
                        
                        <div class="d-grid" *ngIf="appointment.status !== 'completed' && isToday(appointment.appointment_date)">
                          <button class="btn btn-success btn-sm" 
                                  (click)="markConsultationDone(appointment)"
                                  [disabled]="isUpdating">
                            <span *ngIf="isUpdating" class="loading-spinner me-2"></span>
                            <i class="fas fa-check me-2"></i>Mark Consultation Done
                          </button>
                        </div>
                        
                        <div *ngIf="appointment.status === 'completed'" class="alert alert-success mb-0 mt-2">
                          <i class="fas fa-check-circle me-2"></i>
                          Consultation completed - Patient thanked!
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <ng-template #noAppointments>
              <div class="text-center py-5">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No appointments scheduled</h5>
                <p class="text-muted">Patients can book appointments with you from the patient portal</p>
              </div>
            </ng-template>
          </div>
        </div>
      </div>

      <ng-template #notLoggedIn>
        <div class="text-center py-5">
          <i class="fas fa-lock fa-3x text-muted mb-3"></i>
          <h4 class="text-muted mb-3">Access Denied</h4>
          <p class="text-muted mb-4">Please login from the Doctor Portal to access your dashboard</p>
          <a routerLink="/doctors" class="btn btn-primary">
            <i class="fas fa-sign-in-alt me-2"></i>Go to Doctor Portal
          </a>
        </div>
      </ng-template>
    </div>
  `
})
export class DoctorDashboardComponent implements OnInit {
  currentDoctor: Doctor | null = null;
  appointments: Appointment[] = [];
  isUpdating = false;

  constructor(
    private appointmentService: AppointmentService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadCurrentDoctor();
    if (this.currentDoctor) {
      this.loadAppointments();
    }
  }

  loadCurrentDoctor() {
    const doctorData = localStorage.getItem('currentDoctor');
    if (doctorData) {
      this.currentDoctor = JSON.parse(doctorData);
    }
  }

  loadAppointments() {
    if (this.currentDoctor?.id) {
      this.appointmentService.getDoctorAppointments(this.currentDoctor.id).subscribe({
        next: (appointments) => {
          this.appointments = appointments.sort((a, b) => 
            new Date(b.appointment_date).getTime() - new Date(a.appointment_date).getTime()
          );
        },
        error: (error) => {
          console.error('Error loading appointments:', error);
        }
      });
    }
  }

  getTodayAppointments(): Appointment[] {
    const today = new Date().toISOString().split('T')[0];
    return this.appointments.filter(app => app.appointment_date === today);
  }

  isToday(dateStr: string): boolean {
    const today = new Date().toISOString().split('T')[0];
    return dateStr === today;
  }

  formatDate(dateStr: string): string {
    const date = new Date(dateStr);
    return date.toLocaleDateString();
  }

  markConsultationDone(appointment: Appointment) {
    if (!appointment.id) return;
    
    this.isUpdating = true;
    this.appointmentService.updateAppointmentStatus(appointment.id, 'completed').subscribe({
      next: (updatedAppointment) => {
        // Update the appointment in the local array
        const index = this.appointments.findIndex(a => a.id === appointment.id);
        if (index !== -1) {
          this.appointments[index] = updatedAppointment;
        }
        this.isUpdating = false;
      },
      error: (error) => {
        console.error('Error updating appointment:', error);
        this.isUpdating = false;
      }
    });
  }

  logout() {
    localStorage.removeItem('currentDoctor');
    this.router.navigate(['/doctors']);
  }
}