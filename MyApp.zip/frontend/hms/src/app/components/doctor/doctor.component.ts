import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DoctorService } from '../../services/doctor.service';
import { Doctor } from '../../models/doctor/doctor.model';

@Component({
  selector: 'app-doctor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container my-5">
      <h2 class="section-title">Doctor Portal</h2>
      
      <!-- Doctor Registration Form -->
      <div class="card mb-5 fade-in">
        <div class="card-header">
          <h4><i class="fas fa-user-md me-2"></i>Doctor Registration</h4>
        </div>
        <div class="card-body">
          <form (ngSubmit)="saveDoctor()" #doctorForm="ngForm">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Doctor Name *</label>
                <input type="text" class="form-control" [(ngModel)]="newDoctor.name" name="name" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Department *</label>
                <select class="form-control" [(ngModel)]="newDoctor.department" name="department" required>
                  <option value="">Select Department</option>
                  <option value="Cardiology">Cardiology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="Pediatrics">Pediatrics</option>
                  <option value="Dermatology">Dermatology</option>
                  <option value="General Medicine">General Medicine</option>
                  <option value="Surgery">Surgery</option>
                  <option value="Gynecology">Gynecology</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Years of Experience *</label>
                <input type="number" class="form-control" [(ngModel)]="newDoctor.experience" name="experience" required min="1">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Available Time Slots *</label>
                <div class="mt-2">
                  <div class="time-slot" 
                       *ngFor="let slot of availableTimeSlots" 
                       [class.selected]="isSlotSelected(slot)"
                       (click)="toggleTimeSlot(slot)">
                    {{slot}}
                  </div>
                </div>
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary btn-lg" [disabled]="!doctorForm.form.valid || newDoctor.available_slots.length === 0 || isLoading">
                <span *ngIf="isLoading" class="loading-spinner me-2"></span>
                <i class="fas fa-save me-2"></i>Register Doctor
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Success Message -->
      <div class="alert alert-success fade-in" *ngIf="showSuccessMessage">
        <i class="fas fa-check-circle me-2"></i>
        Doctor registered successfully!
      </div>

      <!-- Doctor Login Form -->
      <div class="card mb-5 fade-in">
        <div class="card-header">
          <h4><i class="fas fa-sign-in-alt me-2"></i>Doctor Login</h4>
        </div>
        <div class="card-body">
          <form (ngSubmit)="loginDoctor()" #loginForm="ngForm">
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Doctor Name *</label>
                <input type="text" class="form-control" [(ngModel)]="loginData.name" name="loginName" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Department *</label>
                <select class="form-control" [(ngModel)]="loginData.department" name="loginDepartment" required>
                  <option value="">Select Department</option>
                  <option value="Cardiology">Cardiology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="Pediatrics">Pediatrics</option>
                  <option value="Dermatology">Dermatology</option>
                  <option value="General Medicine">General Medicine</option>
                  <option value="Surgery">Surgery</option>
                  <option value="Gynecology">Gynecology</option>
                </select>
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-success btn-lg" [disabled]="!loginForm.form.valid || isLoginLoading">
                <span *ngIf="isLoginLoading" class="loading-spinner me-2"></span>
                <i class="fas fa-sign-in-alt me-2"></i>Login to Dashboard
              </button>
            </div>
          </form>
          
          <div class="alert alert-danger mt-3" *ngIf="loginError">
            <i class="fas fa-exclamation-circle me-2"></i>
            {{loginError}}
          </div>
        </div>
      </div>

      <!-- Registered Doctors -->
      <div class="card fade-in">
        <div class="card-header">
          <h4><i class="fas fa-users me-2"></i>Our Medical Team ({{doctors.length}})</h4>
        </div>
        <div class="card-body">
          <div class="row" *ngIf="doctors.length > 0; else noDoctors">
            <div class="col-lg-6 col-xl-4 mb-4" *ngFor="let doctor of doctors">
              <div class="card doctor-card h-100">
                <div class="card-body">
                  <div class="d-flex align-items-start mb-3">
                    <div class="doctor-avatar me-3">
                      {{doctor.name.charAt(0).toUpperCase()}}
                    </div>
                    <div class="flex-grow-1">
                      <h5 class="card-title mb-1">Dr. {{doctor.name}}</h5>
                      <span class="badge badge-department">{{doctor.department}}</span>
                    </div>
                  </div>
                  
                  <div class="doctor-details mb-3">
                    <p class="mb-2">
                      <i class="fas fa-graduation-cap me-2 text-primary"></i>
                      {{doctor.experience}} years experience
                    </p>
                    <p class="mb-2">
                      <i class="fas fa-clock me-2 text-success"></i>
                      Available Slots:
                    </p>
                    <div class="available-slots">
                      <span class="time-slot me-1 mb-1" *ngFor="let slot of doctor.available_slots">
                        {{slot}}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <ng-template #noDoctors>
            <div class="text-center py-5">
              <i class="fas fa-user-md-slash fa-3x text-muted mb-3"></i>
              <h5 class="text-muted">No doctors registered yet</h5>
              <p class="text-muted">Register the first doctor using the form above</p>
            </div>
          </ng-template>
        </div>
      </div>
    </div>
  `
})
export class DoctorComponent implements OnInit {
  doctors: Doctor[] = [];
  newDoctor: Doctor = {
    name: '',
    department: '',
    experience: 0,
    available_slots: []
  };
  
  loginData = {
    name: '',
    department: ''
  };
  
  availableTimeSlots = [
    '09:00 AM - 10:00 AM',
    '10:00 AM - 11:00 AM',
    '11:00 AM - 12:00 PM',
    '02:00 PM - 03:00 PM',
    '03:00 PM - 04:00 PM',
    '04:00 PM - 05:00 PM',
    '05:00 PM - 06:00 PM'
  ];
  
  showSuccessMessage = false;
  isLoading = false;
  isLoginLoading = false;
  loginError = '';

  constructor(
    private doctorService: DoctorService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
      },
      error: (error) => {
        console.error('Error loading doctors:', error);
      }
    });
  }

  toggleTimeSlot(slot: string) {
    const index = this.newDoctor.available_slots.indexOf(slot);
    if (index > -1) {
      this.newDoctor.available_slots.splice(index, 1);
    } else {
      this.newDoctor.available_slots.push(slot);
    }
  }

  isSlotSelected(slot: string): boolean {
    return this.newDoctor.available_slots.includes(slot);
  }

  saveDoctor() {
    this.isLoading = true;
    this.doctorService.createDoctor(this.newDoctor).subscribe({
      next: (data) => {
        this.doctors.push(data);
        this.newDoctor = { name: '', department: '', experience: 0, available_slots: [] };
        this.showSuccessMessage = true;
        this.isLoading = false;
        
        setTimeout(() => {
          this.showSuccessMessage = false;
        }, 3000);
      },
      error: (error) => {
        console.error('Error saving doctor:', error);
        this.isLoading = false;
      }
    });
  }

  loginDoctor() {
    this.isLoginLoading = true;
    this.loginError = '';
    
    this.doctorService.loginDoctor(this.loginData.name, this.loginData.department).subscribe({
      next: (doctor) => {
        this.isLoginLoading = false;
        // Store doctor data in localStorage for dashboard access
        localStorage.setItem('currentDoctor', JSON.stringify(doctor));
        this.router.navigate(['/doctor-dashboard']);
      },
      error: (error) => {
        this.isLoginLoading = false;
        this.loginError = 'Invalid doctor credentials. Please check your name and department.';
        console.error('Login error:', error);
      }
    });
  }
}