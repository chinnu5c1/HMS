import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { RouterOutlet, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { appConfig } from './app/app.config';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterModule],
  template: `
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" routerLink="/">
          <i class="fas fa-hospital-alt me-2"></i>MediCare HMS
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">
                <i class="fas fa-home me-1"></i>Home
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/patients" routerLinkActive="active">
                <i class="fas fa-users me-1"></i>Patients
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/doctors" routerLinkActive="active">
                <i class="fas fa-user-md me-1"></i>Doctors
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/appointments" routerLinkActive="active">
                <i class="fas fa-calendar-alt me-1"></i>Appointments
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/doctor-dashboard" routerLinkActive="active">
                <i class="fas fa-tachometer-alt me-1"></i>Dashboard
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <router-outlet></router-outlet>

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-4">
            <h5>MediCare Hospital</h5>
            <p class="mb-0">Advanced Healthcare Management System providing quality care with modern technology.</p>
          </div>
          <div class="col-md-4 mb-4">
            <h5>Quick Links</h5>
            <ul class="list-unstyled">
              <li><a routerLink="/patients">Patient Services</a></li>
              <li><a routerLink="/doctors">Doctor Portal</a></li>
              <li><a routerLink="/appointments">Book Appointment</a></li>
            </ul>
          </div>
          <div class="col-md-4 mb-4">
            <h5>Contact Info</h5>
            <p class="mb-1"><i class="fas fa-phone me-2"></i>+1 (555) 123-4567</p>
            <p class="mb-1"><i class="fas fa-envelope me-2"></i>info&#64;medicare.com</p>
            <p class="mb-0"><i class="fas fa-map-marker-alt me-2"></i>123 Healthcare St, Medical City</p>
          </div>
        </div>
        <hr class="my-4">
        <div class="text-center">
          <p class="mb-0">&copy; 2025 MediCare Hospital Management System. All rights reserved.</p>
        </div>
      </div>
    </footer>
  `
})
export class App {}

bootstrapApplication(App, appConfig);